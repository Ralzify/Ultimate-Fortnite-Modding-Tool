#pragma once

#include "Core.h"
#include "Dom/JsonObject.h"
#include "PhysicsEngine/PhysicsAsset.h"
#include "Animation/AnimBlueprint.h"
#include "Animation/Skeleton.h"
#include "PhysicsEngine/PhysicsConstraintTemplate.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "PhysicsImporter.generated.h"

UCLASS(BlueprintType)
class UPhysicsImporter : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Physics")
    static UPhysicsAsset* ImportPhysicsAsset(
        const FString& JsonString,
        const FString& PackagePath,
        const FString& AssetName,
        const FString& SkeletalMeshPath = TEXT(""));

    UFUNCTION(BlueprintCallable, Category = "Physics")
    static UAnimBlueprint* CreateAnimBlueprint(
        const FString& PackagePath,
        const FString& AssetName,
        USkeleton* Skeleton);

    UFUNCTION(BlueprintCallable, Category = "Physics")
    static bool BuildCopyPoseAnimGraph(UAnimBlueprint* AnimBlueprint);

    UFUNCTION(BlueprintCallable, Category = "Physics")
    static bool BuildRigidBodyAnimGraph(UAnimBlueprint* AnimBlueprint, const TArray<UPhysicsAsset*>& PhysicsAssets);

    UFUNCTION(BlueprintCallable, Category = "Physics")
    static bool BuildAnimGraph(UAnimBlueprint* AnimBlueprint, const TArray<UPhysicsAsset*>& PhysicsAssets);

private:
    static FName GetExportNameOfSubobject(const FString& PackageIndex);
    static TMap<FName, TSharedPtr<FJsonObject>> BuildExportMap(const TArray<TSharedPtr<FJsonValue>>& ExportsArray);
    static void DeserializeBodySetup(const TSharedPtr<FJsonObject>& Properties, UBodySetup* BodySetup);
    static void DeserializeConstraintTemplate(const TSharedPtr<FJsonObject>& Properties, UPhysicsConstraintTemplate* ConstraintTemplate);
    static void DeserializeCollisionDisableTable(const TSharedPtr<FJsonObject>& AssetData, UPhysicsAsset* PhysicsAsset);
};